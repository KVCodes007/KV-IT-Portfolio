# KV & CO Jarvis — Customer Support Assistant Demo

A lightweight browser-based assistant concept for answering common computer repair questions. It is intentionally simple so you can understand and customise it before adding an AI API.

## Features

- Text-based customer questions
- Local FAQ matching (no API key and no paid service)
- Browser text-to-speech replies
- Optional speech recognition where the browser supports it
- Clear note when the question is outside the included FAQ knowledge base

## Run it

From this folder:

```bash
python -m http.server 8000
```

Visit `http://localhost:8000`.

You can also open `index.html` directly, but using a local server is more reliable for browser features.

## Files

- `index.html` — page structure
- `style.css` — responsive styling
- `app.js` — FAQ matching, chat display, voice playback and optional microphone input
- `knowledge-base.js` — editable answers and keywords

## Customise the assistant

Edit `knowledge-base.js` to add your actual service details, supported devices, prices, business hours, and policies. Only publish information that KV & CO is comfortable sharing publicly.

## Important limitation

This demo is FAQ-driven, not a generative AI model. It does not book jobs, diagnose hardware reliably, or send customer data to a server. Before using it with real customers, add clear escalation to a human technician and verify all service claims. Browser speech recognition may be unavailable or may require permission.
