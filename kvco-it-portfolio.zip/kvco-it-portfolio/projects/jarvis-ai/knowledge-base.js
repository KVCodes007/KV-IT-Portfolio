// Edit these example entries with verified KV & CO business information.
window.KNOWLEDGE_BASE = [
  {
    keywords: ["service", "services", "repair", "offer", "help"],
    answer: "The example service list includes computer repair, Windows installation, software installation, and custom PC building. Confirm service availability and pricing with KV & CO before promising a job."
  },
  {
    keywords: ["custom pc", "build pc", "pc build", "gaming pc", "computer build"],
    answer: "KV & CO can use this assistant to collect a customer's budget, intended use, and preferred parts for a custom PC enquiry. A technician should confirm compatibility, stock, and the final quote."
  },
  {
    keywords: ["windows", "install windows", "windows installation", "reinstall"],
    answer: "Windows installation may involve backing up files, checking the device's licence and drivers, and reinstalling the operating system. Customers should back up important data first; data loss is possible during installation."
  },
  {
    keywords: ["slow", "slow pc", "computer slow", "lagging"],
    answer: "Start with a restart, check free storage, and inspect Task Manager for unusually high CPU, memory, or disk usage. Avoid deleting unknown system files. If the issue continues, ask a technician to inspect the device."
  },
  {
    keywords: ["price", "cost", "how much", "pricing", "rate"],
    answer: "I don't have verified current pricing in this demo. Please contact KV & CO for a quote after describing the device and the service needed."
  },
  {
    keywords: ["contact", "whatsapp", "phone", "email", "book", "appointment"],
    answer: "Contact details have not been configured in this demo. Add the approved business contact information to the website and this knowledge base before publishing."
  },
  {
    keywords: ["thank", "thanks", "thank you"],
    answer: "You're welcome. Is there anything else I can help you with?"
  },
  {
    keywords: ["hello", "hi", "hey", "good morning", "good afternoon"],
    answer: "Hello! Welcome to KV & CO. What computer issue or service can I help you with?"
  }
];
