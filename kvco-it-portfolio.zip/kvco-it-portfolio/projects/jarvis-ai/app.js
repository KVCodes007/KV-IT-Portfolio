const form = document.querySelector("#chat-form");
const input = document.querySelector("#question");
const messages = document.querySelector("#messages");
const voiceToggle = document.querySelector("#voice-toggle");
const micButton = document.querySelector("#mic-button");
const clearButton = document.querySelector("#clear-button");
const notice = document.querySelector("#notice");
let voiceEnabled = true;

function addMessage(text, role) {
  const bubble = document.createElement("div");
  bubble.className = `bubble ${role}`;
  const speaker = document.createElement("span");
  speaker.className = "speaker";
  speaker.textContent = role === "assistant" ? "JARVIS" : "YOU";
  const paragraph = document.createElement("p");
  paragraph.textContent = text;
  bubble.append(speaker, paragraph);
  messages.appendChild(bubble);
  messages.scrollTop = messages.scrollHeight;
}

function normalise(text) {
  return text.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ").trim();
}

function findAnswer(question) {
  const q = normalise(question);
  let best = null;
  let bestScore = 0;
  for (const item of window.KNOWLEDGE_BASE || []) {
    const score = item.keywords.reduce((sum, keyword) => {
      const k = normalise(keyword);
      return sum + (q.includes(k) ? (k.includes(" ") ? 3 : 1) : 0);
    }, 0);
    if (score > bestScore) { best = item; bestScore = score; }
  }
  if (best && bestScore > 0) return best.answer;
  return "I don't have a verified answer for that yet. Please describe the issue to a KV & CO technician. You can add more answers in knowledge-base.js.";
}

function speak(text) {
  if (!voiceEnabled || !("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 1;
  utterance.pitch = 0.95;
  window.speechSynthesis.speak(utterance);
}

function ask(question) {
  const clean = question.trim();
  if (!clean) return;
  addMessage(clean, "user");
  input.value = "";
  const answer = findAnswer(clean);
  addMessage(answer, "assistant");
  speak(answer);
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  ask(input.value);
});

document.querySelectorAll("[data-question]").forEach((button) => {
  button.addEventListener("click", () => ask(button.dataset.question));
});

voiceToggle.addEventListener("click", () => {
  voiceEnabled = !voiceEnabled;
  voiceToggle.textContent = `Voice: ${voiceEnabled ? "On" : "Off"}`;
  voiceToggle.setAttribute("aria-pressed", String(voiceEnabled));
  if (!voiceEnabled && "speechSynthesis" in window) window.speechSynthesis.cancel();
});

clearButton.addEventListener("click", () => {
  if ("speechSynthesis" in window) window.speechSynthesis.cancel();
  messages.replaceChildren();
  addMessage("Chat cleared. Hello! I'm the KV & CO support demo. What can I help you with today?", "assistant");
});

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (!SpeechRecognition) {
  micButton.disabled = true;
  micButton.textContent = "🎙 Microphone unavailable in this browser";
  micButton.title = "Use a supported browser or type your question.";
} else {
  const recognition = new SpeechRecognition();
  recognition.lang = "en-MY";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  micButton.addEventListener("click", () => {
    notice.textContent = "Listening… Your browser may ask for microphone permission.";
    try { recognition.start(); } catch (_) { notice.textContent = "Microphone is already active. Try again in a moment."; }
  });
  recognition.addEventListener("result", (event) => {
    const transcript = event.results[0][0].transcript;
    input.value = transcript;
    notice.textContent = `Heard: “${transcript}”`;
    ask(transcript);
  });
  recognition.addEventListener("error", (event) => {
    notice.textContent = `Microphone issue: ${event.error}. You can still type your question.`;
  });
  recognition.addEventListener("end", () => {
    if (notice.textContent === "Listening… Your browser may ask for microphone permission.") {
      notice.textContent = "No speech detected. You can still type your question.";
    }
  });
}
