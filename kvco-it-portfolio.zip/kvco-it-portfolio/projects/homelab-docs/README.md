# Homelab Documentation

A portfolio-friendly record of a small Ubuntu Server homelab. Keep this file accurate to the services actually running on your machine.

## Current-state inventory template

Fill in only non-sensitive details. Do not publish passwords, public IP addresses, Tailscale keys, router admin URLs, or customer data.

| Component | Notes |
|---|---|
| Host OS | Ubuntu Server (record your exact release with `lsb_release -a`) |
| Containers | Docker |
| Management UI | Portainer (if still installed) |
| DNS filtering | Pi-hole (if still installed) |
| Monitoring | Uptime Kuma |
| Remote access | Tailscale |
| Storage | Record disk layout and free space |
| Network | UniFi/Deco environment; redact private details |

## Useful commands

```bash
# OS version
lsb_release -a

# Docker status
systemctl status docker --no-pager

# Running containers
docker ps

# Disk capacity
df -h

# Memory
free -h

# Recent service logs (replace SERVICE with a container name)
docker logs --tail 100 SERVICE
```

## Troubleshooting workflow

1. Reproduce the problem and record the exact error.
2. Check service status and logs before changing settings.
3. Confirm the host has disk space, memory, and network connectivity.
4. Change one thing at a time.
5. Verify the fix and write down the result.

## Uptime Kuma: localhost / 127.0.1.1 issue

`127.0.0.1` and `127.0.1.1` are loopback addresses: they refer to the machine itself. A monitor configured against a loopback address may test from the wrong network perspective. For a service running on another device, use that device's reachable LAN address or hostname. For a container, networking depends on whether the target is on the host, in the same Docker network, or elsewhere. Do not expose the dashboard publicly just to make monitoring work.

## Safe backup checklist

- [ ] Back up Compose files and non-secret configuration.
- [ ] Keep passwords, tokens, and `.env` files out of Git.
- [ ] Back up important application data separately.
- [ ] Test restoring a small sample.
- [ ] Record how to recover if the boot drive fails.

## Example Compose file

See `docker-compose.example.yml`. It is an illustrative template, not a replacement for reviewing each application's official documentation and security requirements.
