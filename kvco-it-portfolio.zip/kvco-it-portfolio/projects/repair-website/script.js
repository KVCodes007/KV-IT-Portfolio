// Configure a real, approved contact URL before publishing.
// Example: const CONTACT_URL = "https://wa.me/60XXXXXXXXX";
const CONTACT_URL = "";

const button = document.querySelector("#contact-button");
const note = document.querySelector("#contact-note");

button.addEventListener("click", () => {
  if (CONTACT_URL) {
    window.open(CONTACT_URL, "_blank", "noopener,noreferrer");
    return;
  }
  note.textContent = "Contact link not configured yet. Edit CONTACT_URL in script.js, then test it before publishing.";
  note.setAttribute("role", "status");
});
