# KV & CO Computer Repair Website

A responsive static landing page for a small computer support business.

## Run locally

```bash
python -m http.server 8001
```

Visit `http://localhost:8001`.

## Before publishing

- Verify the services listed in `index.html`.
- Replace the example contact details with approved contact links.
- Test on mobile and desktop.
- Check every link.
- Do not add private customer information.

This site is static and does not process payments, book appointments, or store form submissions.
