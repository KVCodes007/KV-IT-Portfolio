# KV & CO — IT Portfolio

A single repository containing three practical IT projects:

1. **Jarvis AI Assistant** — a customer-facing computer-support assistant demo with text input, browser voice playback, and a searchable local FAQ knowledge base.
2. **Homelab Documentation** — documentation and example Docker Compose configuration for a small Ubuntu Server homelab.
3. **Computer Repair Website** — a responsive landing page for KV & CO computer repair services.

## Repository structure

```text
kvco-it-portfolio/
├── projects/
│   ├── jarvis-ai/
│   ├── homelab-docs/
│   └── repair-website/
├── .gitignore
└── README.md
```

## Quick start

### 1. Jarvis AI Assistant

No API key is required for the included demo. It uses a small local FAQ knowledge base and the browser's built-in speech synthesis for spoken replies.

```bash
cd projects/jarvis-ai
python -m http.server 8000
```

Open `http://localhost:8000` in your browser.

**Note:** This is a rule/FAQ-based demo, not a large language model. Browser speech recognition support varies by browser; the text input works without it.

### 2. Homelab documentation

Open `projects/homelab-docs/README.md` and follow the checklist. Review `docker-compose.example.yml` before using it. Replace example values, and do not publish secrets, public IPs, VPN keys, or private configuration.

### 3. Computer repair website

```bash
cd projects/repair-website
python -m http.server 8001
```

Open `http://localhost:8001`.

Edit `script.js` and `index.html` to replace the example contact details with your approved business details.

## Publish to GitHub

1. Create a new **empty** repository on GitHub, for example `kvco-it-portfolio`.
2. Extract this project folder on your computer.
3. Open a terminal inside the extracted `kvco-it-portfolio` folder.
4. Run:

```bash
git init
git add .
git commit -m "Initial commit: three IT portfolio projects"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/kvco-it-portfolio.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. If Git asks you to sign in, complete GitHub's authentication flow; do not put your password or token into project files.

## Security checklist

- Never commit API keys, passwords, router credentials, private keys, `.env` files, or customer information.
- Use placeholders in screenshots and documentation.
- Review every file before pushing to a public repository.
- The included homelab Compose file is an example, not a production-ready security configuration.

## Suggested learning path

1. Read each project's README.
2. Run the website and Jarvis demo locally.
3. Edit one small feature and test it.
4. Commit the change with a clear message.
5. Push the update to GitHub.
